package devops.demo;

public class Dummy1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Dummy2 d2=new Dummy2();
		Dummy3 d3=new Dummy3();
		Dummy4 d4=new Dummy4();
		Dummy5 d5=new Dummy5();
		Dummy6 d6=new Dummy6();
		Dummy7 d7=new Dummy7();
		Dummy8 d8=new Dummy8();
		Dummy9 d9=new Dummy9();
		Dummy10 d10=new Dummy10();
		
		d2.whichClass(d2);
		d3.whichClass(d3);
		d4.whichClass(d4);
		d5.whichClass(d5);
		d6.whichClass(d6);
		d7.whichClass(d7);
		d8.whichClass(d8);
		d9.whichClass(d9);
		d10.whichClass(d10);
		
		
	}

}
